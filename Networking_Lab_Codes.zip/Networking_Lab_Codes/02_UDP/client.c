#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int main()
{
    int s, n;
    char msg[100];
    struct sockaddr_in server = {0};

    s = socket(AF_INET, SOCK_DGRAM, 0);

    server.sin_family = AF_INET;
    server.sin_port = htons(8080);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    printf("Enter message: ");
    fgets(msg, sizeof(msg), stdin);
    sendto(s, msg, strlen(msg), 0,
           (struct sockaddr *)&server, sizeof(server));

    n = recvfrom(s, msg, sizeof(msg) - 1, 0, NULL, NULL);
    if (n > 0) {
        msg[n] = '\0';
        printf("Server says: %s\n", msg);
    }

    close(s);
    return 0;
}
