#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int main()
{
    int s, n;
    char msg[100];
    struct sockaddr_in server = {0}, client;
    socklen_t len = sizeof(client);

    s = socket(AF_INET, SOCK_DGRAM, 0);

    server.sin_family = AF_INET;
    server.sin_port = htons(8080);
    server.sin_addr.s_addr = INADDR_ANY;

    bind(s, (struct sockaddr *)&server, sizeof(server));

    n = recvfrom(s, msg, sizeof(msg) - 1, 0,
                 (struct sockaddr *)&client, &len);
    if (n > 0) {
        msg[n] = '\0';
        printf("Client says: %s\n", msg);
        sendto(s, msg, strlen(msg), 0,
               (struct sockaddr *)&client, len);
    }

    close(s);
    return 0;
}
